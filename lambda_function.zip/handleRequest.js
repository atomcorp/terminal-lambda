"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("./utils/utils");
const getUniqueThemes = (itermThemes, customThemes) => [
    ...itermThemes,
    ...customThemes.filter((customTheme) => !itermThemes
        .map((itermTheme) => itermTheme.name)
        .includes(customTheme.name)),
];
const setThemesWithMeta = (themes, credits) => {
    return themes.map((theme) => {
        const themeCredit = credits.find((credit) => credit.themeNames.includes(theme.name));
        return Object.assign(Object.assign({}, theme), { meta: {
                isDark: (0, utils_1.getIsDark)(theme.background),
                credits: themeCredit !== undefined ? themeCredit.sources : null,
            } });
    });
};
const handleRequests = (props) => {
    const uniqueThemes = getUniqueThemes(props[0], props[1]);
    const mergedCredits = [...props[2], ...props[3]];
    const themesWithMeta = setThemesWithMeta(uniqueThemes, mergedCredits);
    return themesWithMeta.sort((a, b) => a.name.toUpperCase() > b.name.toUpperCase() ? 1 : -1);
};
exports.default = handleRequests;
